# elephant
操作系统真象还原
